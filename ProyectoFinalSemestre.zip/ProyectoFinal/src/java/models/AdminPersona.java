package models;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author brandon
 * @version 1
 */
@WebServlet("/AdminPersona")
public class AdminPersona extends HttpServlet {

    PersonaDAO perDAO = new PersonaDAO();
    Personal per;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String i = request.getParameter("id");
        String n = request.getParameter("nombre");
        String pA = request.getParameter("papellido");
        String sA = request.getParameter("sapellido");
        String ca = request.getParameter("cargo");
        if (i != null && !n.equalsIgnoreCase("") && !pA.equalsIgnoreCase("") && !sA.equalsIgnoreCase("") && !ca.equalsIgnoreCase("")) {
            per = new Personal(Integer.parseInt(i), n, pA, sA, ca);
            perDAO.agregarPersonal(per);
            request.setAttribute("mensaje", "Persona agregada satisfactoriamente");
            RequestDispatcher view = request.getRequestDispatcher("RegistroPersonal.jsp");
            view.forward(request, response);
        }
    }
}
