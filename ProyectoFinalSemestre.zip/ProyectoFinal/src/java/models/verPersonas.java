package models;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import models.Personal;
import models.PersonaDAO;

/**
 *
 * @author brandon
 * @version 1
 */
@WebServlet("/verPersonas")
public class verPersonas extends HttpServlet {

    PersonaDAO perDAO = new PersonaDAO();
    ArrayList<Personal> personas;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        personas = perDAO.obtenerPersonal();
        RequestDispatcher view = request.getRequestDispatcher("ver_personas.jsp");
        request.setAttribute("personas", personas);
        view.forward(request, response);
    }

}
