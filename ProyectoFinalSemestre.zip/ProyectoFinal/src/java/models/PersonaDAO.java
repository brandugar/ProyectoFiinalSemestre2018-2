/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author brandon
 * @version 1
 */
import db.DB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import models.Personal;

public class PersonaDAO {

    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    DB conexion = null;

    /**Método para agregar persona a la base de datos
     */
    public void agregarPersonal(Personal p) {

        try {
            conn = conexion.getConexion();
            Statement st = conn.createStatement();
            String query = "insert into Personal(ID,Nombre,PrimerApellido,SegundoApellido,Cargo) values (?,?,?,?,?)";
            ps = conn.prepareStatement(query);
            ps.setInt(1, p.getId());
            ps.setString(2, p.getNombre());
            ps.setString(3, p.getPrimerApellido());
            ps.setString(4, p.getSegundoApellido());
            ps.setString(5, p.getCargo());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                /* ignored */ }
        }
    }

    /**Método para listar las personas registradas en la tabla Personal de la base de datos
     */
    public ArrayList<Personal> obtenerPersonal() {
        ArrayList<Personal> personas = new ArrayList<Personal>();
        try {
            conn = conexion.getConexion();
            String query = "SELECT * FROM Personal";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                Personal persona = new Personal();
                persona.setId(rs.getInt("ID"));
                persona.setNombre(rs.getString("Nombre"));
                persona.setPrimerApellido(rs.getString("PrimerApellido"));
                persona.setSegundoApellido(rs.getString("SegundoApellido"));
                persona.setCargo(rs.getString("Cargo"));
                personas.add(persona);
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        return personas;
    }
/**Método para eliminar personal de la SIU de la base de datos de la tabla Personal*/
    public void eliminarPersonal(int id)  {
        String query = "DELETE FROM Personal WHERE ID=" + id + "";
        try {
            conn = conexion.getConexion();
            Statement st = conn.createStatement();
            st.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        } 
    }
}
