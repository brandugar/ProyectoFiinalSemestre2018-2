/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author brandon
 * @version 1
 */
import db.DB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import models.Personal;

public class ProyectoDAO {

    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    DB conexion = null;

    /**Método para agregar Proyecto a la base de datos*/
    public void agregarProyecto(Proyecto p) {

        try {
            conn = conexion.getConexion();
            Statement st = conn.createStatement();
            String query = "insert into Proyecto(ID,NombreProyecto,Estado,Resultado,CostosPersonal,CostosInsumos,CostoTotal,Monetizacion,Grupo) values (?,?,?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(query);
            ps.setInt(1, p.getId());
            ps.setString(2, p.getNombreProyecto());
            ps.setString(3, p.getEstado());
            ps.setString(4, p.getResultado());
            ps.setInt(5, p.getCostosPersonal());
            ps.setInt(6, p.getCostosInsumos());
            ps.setInt(7, p.getCostoTotal());
            ps.setInt(8, p.getMonetizacion());
            ps.setString(9, p.getGrupoInvestigacion());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                /* ignored */ }
        }
    }

    /**Método para listar los proyectos registrados en la base de datos*/
    public ArrayList<Proyecto> obtenerProyectos() {
        ArrayList<Proyecto> proyectos = new ArrayList<Proyecto>();
        try {
            conn = conexion.getConexion();
            String query = "SELECT * FROM Proyecto ORDER BY Monetizacion DESC";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                Proyecto proyecto = new Proyecto();
                proyecto.setId(rs.getInt("ID"));
                proyecto.setNombreProyecto(rs.getString("NombreProyecto"));
                proyecto.setGrupoInvestigacion(rs.getString("Grupo"));
                proyecto.setEstado(rs.getString("Estado"));
                proyecto.setResultado(rs.getString("Resultado"));
                proyecto.setCostosPersonal(rs.getInt("CostosPersonal"));
                proyecto.setCostosInsumos(rs.getInt("CostosInsumos"));
                proyecto.setCostoTotal(rs.getInt("CostoTotal"));
                proyecto.setMonetizacion(rs.getInt("Monetizacion"));
                proyectos.add(proyecto);
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        return proyectos;
    }

    /**Método para listar los proyectos Cerrados registrados en la base de datos*/
    public ArrayList<Proyecto> obtenerProyectosCerrados() {
        ArrayList<Proyecto> proyectos = new ArrayList<Proyecto>();
        try {
            conn = conexion.getConexion();
            String query = "SELECT * FROM Proyecto WHERE Estado='Cerrado' ORDER BY Monetizacion DESC";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                Proyecto proyecto = new Proyecto();
                proyecto.setId(rs.getInt("ID"));
                proyecto.setNombreProyecto(rs.getString("NombreProyecto"));
                proyecto.setGrupoInvestigacion(rs.getString("Grupo"));
                proyecto.setEstado(rs.getString("Estado"));
                proyecto.setResultado(rs.getString("Resultado"));
                proyecto.setCostosPersonal(rs.getInt("CostosPersonal"));
                proyecto.setCostosInsumos(rs.getInt("CostosInsumos"));
                proyecto.setCostoTotal(rs.getInt("CostoTotal"));
                proyecto.setMonetizacion(rs.getInt("Monetizacion"));
                proyectos.add(proyecto);
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        return proyectos;
    }
    /**Método para listar los proyectos Abiertos registrados en la base de datos*/
    public ArrayList<Proyecto> obtenerProyectosAbiertos() {
        ArrayList<Proyecto> proyectos = new ArrayList<Proyecto>();
        try {
            conn = conexion.getConexion();
            String query = "SELECT * FROM Proyecto WHERE Estado='Abierto' ORDER BY Monetizacion DESC";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                Proyecto proyecto = new Proyecto();
                proyecto.setId(rs.getInt("ID"));
                proyecto.setNombreProyecto(rs.getString("NombreProyecto"));
                proyecto.setGrupoInvestigacion(rs.getString("Grupo"));
                proyecto.setEstado(rs.getString("Estado"));
                proyecto.setResultado(rs.getString("Resultado"));
                proyecto.setCostosPersonal(rs.getInt("CostosPersonal"));
                proyecto.setCostosInsumos(rs.getInt("CostosInsumos"));
                proyecto.setCostoTotal(rs.getInt("CostoTotal"));
                proyecto.setMonetizacion(rs.getInt("Monetizacion"));
                proyectos.add(proyecto);
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        return proyectos;
    }

    /**Método con el trabajo de buscar si en la tabla PersonalProyecto 
    hay registros de personas que esten vinculadas a algun grupo de investigacion, todo con el fin de
    facilitar el calculo de costos de personal.*/
    public int verificaGrupo(String grupo) {
        int contador = 0;
        try {
            conn = conexion.getConexion();
            String query = "SELECT * FROM PersonalProyecto WHERE Grupo=" + "'" + grupo + "'";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                contador++;
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        return contador;
    }
    /**Método para modificar costo total*/
    public void actualizarCostoTotal(String grupo, int costoTotal) {

        try {
            conn = conexion.getConexion();
            Statement st = conn.createStatement();
            String query = "UPDATE Proyecto SET CostoTotal = ? " + "WHERE Grupo = " + "'" + grupo + "'";
            ps = conn.prepareStatement(query);
            ps.setInt(1, costoTotal);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                /* ignored */ }
        }
    }
    /**Método para eliminar un proyecto*/
    public void eliminarProyecto(int id) {
        String query = "DELETE FROM Proyecto WHERE ID=" + id + "";
        try {
            conn = conexion.getConexion();
            Statement st = conn.createStatement();
            st.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    /**Método para actualizar la monetizacion de un proyecto, se realiza gracias a un nivel que se le pide al usuario*/
    public void actualizarResultadoMonetizado(int id, String resultado, int nivel) {

        String result = null;
        Proyecto proyecto = new Proyecto();
        try {
            conn = conexion.getConexion();
            Statement st = conn.createStatement();
            String query;
            query = "SELECT * FROM Proyecto WHERE ID=" + "'" + id + "'";
            int monetiza = 0;
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            if (rs.next()) {
                proyecto.setId(rs.getInt("ID"));
                proyecto.setNombreProyecto(rs.getString("NombreProyecto"));
                proyecto.setGrupoInvestigacion(rs.getString("Grupo"));
                proyecto.setEstado(rs.getString("Estado"));
                proyecto.setResultado(rs.getString("Resultado"));
                proyecto.setCostosPersonal(rs.getInt("CostosPersonal"));
                proyecto.setCostosInsumos(rs.getInt("CostosInsumos"));
                proyecto.setCostoTotal(rs.getInt("CostoTotal"));
                proyecto.monetizar(nivel);
                monetiza = proyecto.getMonetizacion();
                result = proyecto.getResultado().concat("\n*".concat(resultado));
                if (result != null) {
                    query = "UPDATE Proyecto SET Resultado = ?, Monetizacion = ? WHERE ID = " + id;
                    ps = conn.prepareStatement(query);
                    ps.setString(1, result);
                    ps.setInt(2, monetiza);
                    ps.executeUpdate();
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
