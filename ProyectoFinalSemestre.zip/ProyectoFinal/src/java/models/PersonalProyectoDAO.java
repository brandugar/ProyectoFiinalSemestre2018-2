/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author brandon
 * @version 1
 */
import db.DB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class PersonalProyectoDAO {

    PreparedStatement ps = null;
    ResultSet rs = null;
    Connection conn = null;
    DB conexion = null;
    ProyectoDAO proDAO = new ProyectoDAO();
    Proyecto pro = new Proyecto();

    /**Método para agregar persona a la tabla PersonalProyecto de la base de datos*/
    public void agregarPersonalProyecto(PersonalProyecto p) {

        try {
            conn = conexion.getConexion();
            Statement st = conn.createStatement();
            String query = "insert into PersonalProyecto(ID,Nombre,PrimerApellido,SegundoApellido,Grupo) values (?,?,?,?,?)";
            ps = conn.prepareStatement(query);
            ps.setInt(1, p.getId());
            ps.setString(2, p.getNombre());
            ps.setString(3, p.getpApellido());
            ps.setString(4, p.getsApellido());
            ps.setString(5, p.getGrupo());
            ps.executeUpdate();
            actualizarProyecto(p.getGrupo());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                rs.close();
            } catch (Exception e) {
                /* ignored */ }
        }
    }

    /**Método para listar las personas registradas en la tabla PersonalProyecto de la base de datos*/
    public ArrayList<PersonalProyecto> obtenerPersonalProyecto() {
        ArrayList<PersonalProyecto> personas = new ArrayList<PersonalProyecto>();
        try {
            conn = conexion.getConexion();
            String query = "SELECT * FROM PersonalProyecto";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();

            while (rs.next()) {
                PersonalProyecto persona = new PersonalProyecto();
                persona.setId(rs.getInt("ID"));
                persona.setNombre(rs.getString("Nombre"));
                persona.setpApellido(rs.getString("PrimerApellido"));
                persona.setsApellido(rs.getString("SegundoApellido"));
                persona.setGrupo(rs.getString("Grupo"));
                personas.add(persona);
            }

        } catch (Exception e) {
            System.out.println(e);
        }

        return personas;
    }

    /**Método para actualizar costo total de un proyecto, ya que el costo aumenta al tener a mas personas*/
    public void actualizarProyecto(String grupo) {
        int personal;
        int insumos;
        int numeroPersonas;
        Proyecto pro = new Proyecto();
        ProyectoDAO proDAO = new ProyectoDAO();
        try {
            conn = conexion.getConexion();
            String query = "SELECT * FROM Proyecto WHERE Grupo=" + "'" + grupo + "'";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            if (rs.next()) {
                personal = rs.getInt("CostosPersonal");
                insumos = rs.getInt("CostosInsumos");
                numeroPersonas = proDAO.verificaGrupo(grupo);
                pro.calculaCostosPersonal(numeroPersonas, personal);
                pro.setCostosInsumos(insumos);
                pro.calculaCostoTotal();
            }
            query = "SELECT * FROM Proyecto";
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            proDAO.actualizarCostoTotal(grupo, pro.getCostoTotal());
        } catch (Exception e) {
            System.out.println(e);
        }
    }
/**método para eliminar personas registradas en un proyecto*/
    public void eliminarPersonalProyecto(int id) {
        String query = "DELETE FROM PersonalProyecto WHERE ID=" + id + "";
        try {
            conn = conexion.getConexion();
            Statement st = conn.createStatement();
            st.executeUpdate(query);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
