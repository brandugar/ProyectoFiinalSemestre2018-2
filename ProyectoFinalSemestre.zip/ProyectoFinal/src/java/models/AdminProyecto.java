package models;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author brandon
 * @version 1
 */
@WebServlet("/AdminProyecto")
public class AdminProyecto extends HttpServlet {

    ProyectoDAO proDAO = new ProyectoDAO();
    Proyecto pro;

    /**sobreescribimos el metodo doPost, este método verifica que al momento de registrar un proyecto, ya hayan grupos de investigación
    que se enfoquen en este proyecto. es decir que para registrar un proyecto se debe de registrar antes un grupo de investigacion.*/
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String i = request.getParameter("id");
        String n = request.getParameter("nombreProyecto");
        String gr = request.getParameter("grupo");
        String es = request.getParameter("estado");
        String in = request.getParameter("insumos");
        String co = request.getParameter("personal");
        String re = "";
        if (i != null && !n.equalsIgnoreCase("") && !gr.equalsIgnoreCase("") && !es.equalsIgnoreCase("") && !co.equalsIgnoreCase("") && proDAO.verificaGrupo(gr) != 0) {
            pro = new Proyecto();
            pro.setId(Integer.parseInt(i));
            pro.setNombreProyecto(n);
            pro.setGrupoInvestigacion(gr);
            pro.setEstado(es);
            pro.setResultado(re);
            pro.setCostosInsumos(Integer.parseInt(in));
            pro.calculaCostosPersonal(proDAO.verificaGrupo(gr), Integer.parseInt(co));
            pro.calculaCostoTotal();
            pro.setMonetizacion(0);
            proDAO.agregarProyecto(pro);
            RequestDispatcher view = request.getRequestDispatcher("RegistroProyecto.jsp");
            request.setAttribute("mensaje", "Proyecto agregado satisfactoriamente");
            view.forward(request, response);
        } else {
            RequestDispatcher view = request.getRequestDispatcher("RegistroProyecto.jsp");
            request.setAttribute("mensaje", "datos incorrectos");
            view.forward(request, response);
        }

    }

}
