package models;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author brandon
 * @version 1
 */
@WebServlet("/AdminPersonalProyecto")
public class AdminPersonalProyecto extends HttpServlet {

    PersonalProyectoDAO perProDAO = new PersonalProyectoDAO();
    PersonalProyecto perPro;
    /*
    sobreescribimos el metodo doPost, el programa no tendrá un limite para agregar personas de un mismo grupo de investigación.
    */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String i = request.getParameter("id");
        String n = request.getParameter("nombre");
        String pA = request.getParameter("papellido");
        String sA = request.getParameter("sapellido");
        String gr = request.getParameter("grupo");
        if (i != null && !n.equalsIgnoreCase("") && !pA.equalsIgnoreCase("") && !sA.equalsIgnoreCase("") && !gr.equalsIgnoreCase("")) {
            perPro = new PersonalProyecto(Integer.parseInt(i), n, pA, sA, gr);
            perProDAO.agregarPersonalProyecto(perPro);
            request.setAttribute("mensaje", "Persona agregada satisfactoriamente");
            RequestDispatcher view = request.getRequestDispatcher("RegistroPersonalProyecto.jsp");
            view.forward(request, response);
        }

    }

}
