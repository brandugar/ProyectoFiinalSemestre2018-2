package models;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author brandon
 * @version 1
 */
@WebServlet("/AdminResultado")
public class AdminResultado extends HttpServlet {

    ProyectoDAO proDAO = new ProyectoDAO();

    /*sobreescribimos el metodo doPost, este método verifica que al momento de registrar un proyecto, ya hayan grupos de investigación
    que se enfoquen en este proyecto. es decir que para registrar un proyecto se debe de registrar antes un grupo de investigacion.*/
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        int i = Integer.parseInt(request.getParameter("id"));
        String resultado = request.getParameter("resultado");
        int nivel = Integer.parseInt(request.getParameter("nivel"));
        if (i != 0) {
            proDAO.actualizarResultadoMonetizado(i, resultado,nivel);
            request.setAttribute("mensaje", "Proyecto agregado satisfactoriamente");
            RequestDispatcher view = request.getRequestDispatcher("index.jsp");
            view.forward(request, response);
        } else {
            request.setAttribute("mensaje", "faltan datos");
            RequestDispatcher view = request.getRequestDispatcher("RegistroResultado.jsp");
            view.forward(request, response);
        }

    }

}
