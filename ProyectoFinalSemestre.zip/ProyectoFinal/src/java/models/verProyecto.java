/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author brandon
 * @version 1
 */
@WebServlet("/verProyecto")
public class verProyecto extends HttpServlet {

    ProyectoDAO proDAO = new ProyectoDAO();
    ArrayList<Proyecto> proyectos;
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String parametro= request.getParameter("estado");
        if (parametro.equalsIgnoreCase("Todos")) {
            proyectos = proDAO.obtenerProyectos();
            RequestDispatcher view = request.getRequestDispatcher("ver_proyecto.jsp");
            request.setAttribute("proyectos", proyectos);
            view.forward(request, response);
        }else if (parametro.equalsIgnoreCase("Cerrado")) {
            proyectos = proDAO.obtenerProyectosCerrados();
            RequestDispatcher view = request.getRequestDispatcher("ver_proyecto.jsp");
            request.setAttribute("proyectos", proyectos);
            view.forward(request, response);
        }else{
            proyectos = proDAO.obtenerProyectosAbiertos();
            RequestDispatcher view = request.getRequestDispatcher("ver_proyecto.jsp");
            request.setAttribute("proyectos", proyectos);
            view.forward(request, response);
        }
    }
}
