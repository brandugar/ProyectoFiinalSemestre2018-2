package models;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.JOptionPane;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author brandon
 * @version 1
 */
@WebServlet("/Remover")
public class Remover extends HttpServlet {

    PersonaDAO perDAO = new PersonaDAO();
    ProyectoDAO proDAO = new ProyectoDAO();
    PersonalProyectoDAO perProDAO = new PersonalProyectoDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String opcion = request.getParameter("opcion");
        String id;
        if (opcion.equalsIgnoreCase("personalSIU")) {
            id = request.getParameter("idPersonalSIU");
            int iD = Integer.parseInt(id);
            perDAO.eliminarPersonal(iD);
            request.setAttribute("mensaje", "Eliminado Correctamente");
            RequestDispatcher view = request.getRequestDispatcher("Eliminar.jsp");
            view.forward(request, response);
        } else if (opcion.equalsIgnoreCase("proyecto")) {
            id = request.getParameter("idProyecto");
            int iD = Integer.parseInt(id);
            proDAO.eliminarProyecto(iD);
            request.setAttribute("mensaje", "Eliminado Correctamente");
            RequestDispatcher view = request.getRequestDispatcher("Eliminar.jsp");
            view.forward(request, response);
        }else{
            id = request.getParameter("idPersonalProyecto");
            int iD = Integer.parseInt(id);
            perProDAO.eliminarPersonalProyecto(iD);
            request.setAttribute("mensaje", "Eliminado Correctamente");
            RequestDispatcher view = request.getRequestDispatcher("Eliminar.jsp");
            view.forward(request, response);
        }
    }

}
