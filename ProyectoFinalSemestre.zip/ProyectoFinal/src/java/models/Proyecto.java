/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

/**
 *
 * @author brandon
 * @version 1
 */
/**Esta clase tiene un atributo costosPersonal que se irá actualizando al tiempo en que se van añadiendo registros en la tabla PersonalProyecto.*/
public class Proyecto {
    private int id;
    private String grupoInvestigacion;
    private String nombreProyecto;
    private String estado;
    private String resultado;
    private int costosPersonal;
    private int costosInsumos;
    private int costoTotal;
    private int numeroPersonas;
    private int monetizacion;
/**creacion del constructor*/
    public Proyecto() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombreProyecto() {
        return nombreProyecto;
    }

    public void setNombreProyecto(String nombreProyecto) {
        this.nombreProyecto = nombreProyecto;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resutado) {
        this.resultado = resutado;
    }

    public int getCostosPersonal() {
        return costosPersonal;
    }

    public void setCostosPersonal(int costosPersonal) {
        this.costosPersonal = costosPersonal;
    }

    public int getCostosInsumos() {
        return costosInsumos;
    }

    public void setCostosInsumos(int costosInsumos) {
        this.costosInsumos = costosInsumos;
    }

    public int getCostoTotal() {
        return costoTotal;
    }

    public void setCostoTotal(int costoTotal) {
        this.costoTotal = costoTotal;
    }

    public int getMonetizacion() {
        return monetizacion;
    }

    public void setMonetizacion(int monetizacion) {
        this.monetizacion = monetizacion;
    }

    public String getGrupoInvestigacion() {
        return grupoInvestigacion;
    }

    public void setGrupoInvestigacion(String grupoInvestigacion) {
        this.grupoInvestigacion = grupoInvestigacion;
    }
    
    public void calculaCostosPersonal(int num,int costoPersona){
        setCostosPersonal(num*costoPersona);
    }
    /*metodo para calcular el costo total sumando el costo de insumos y el costo del personal*/
    public void calculaCostoTotal(){
        setCostoTotal(getCostosPersonal()+getCostosInsumos());
    }
    
    /**Metodo para monetizar, recibe como parámetro un entero que indica el nivel de impacto del resultado*/
    public void monetizar(int nivel){
        switch(nivel){
            case 1:
                setMonetizacion((int)(getCostoTotal()+getCostoTotal()*0.1));
                break;
            case 2:
                setMonetizacion((int)(getCostoTotal()+getCostoTotal()*0.2));
                break;
            case 3:
                setMonetizacion((int)(getCostoTotal()+getCostoTotal()*0.35));
                break;
            case 4:
                setMonetizacion((int)(getCostoTotal()+getCostoTotal()*0.50));
                break;
            case 5:
                setMonetizacion((int)(getCostoTotal()+getCostoTotal()*0.70));
                break;
        }
    }

    public int getNumeroPersonas() {
        return numeroPersonas;
    }

    public void setNumeroPersonas(int numeroPersonas) {
        this.numeroPersonas = numeroPersonas;
    }
}
